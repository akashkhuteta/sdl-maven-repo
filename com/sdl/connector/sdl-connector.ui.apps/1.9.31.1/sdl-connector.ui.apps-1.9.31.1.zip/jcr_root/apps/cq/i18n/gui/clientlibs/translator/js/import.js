/*
 ADOBE CONFIDENTIAL

 Copyright 2016 Adobe Systems Incorporated
 All Rights Reserved.

 NOTICE:  All information contained herein is, and remains
 the property of Adobe Systems Incorporated and its suppliers,
 if any.  The intellectual and technical concepts contained
 herein are proprietary to Adobe Systems Incorporated and its
 suppliers and may be covered by U.S. and Foreign Patents,
 patents in process, and are protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material
 is strictly forbidden unless prior written permission is obtained
 from Adobe Systems Incorporated.
 */
(function (document, XSS, $) {

    "use strict";
    var dictFileName = "";
    var i18nDictUploadSelector = "#i18n-dict-import";

    $(document).ready(function () {
        $(document).on("coral-fileupload:fileadded", "coral-fileupload", function (e) {
            var fileUpload = e.originalEvent.target;
            dictFileName = e.originalEvent.detail.item.file.name;
            $("#filename")[0].value = dictFileName;
            $(i18nDictUploadSelector).removeAttr("disabled");
        });

        var ui = $(window).adaptTo("foundation-ui");

        function addErrorAlertOption(eventStr) {
            $(document).on(eventStr, "coral-fileupload", function (e) {
                ui.notify(Granite.I18n.get("Error"),
                          Granite.I18n.get("Unable to import: {0}", eventStr,
                                           "Import not successful. First argument is import status"), "error");
            });
        }

        function addSuccessAlertOption(eventStr) {
            $(document).on(eventStr, "coral-fileupload", function (e) {
                ui.notify(Granite.I18n.get("Import"),
                          Granite.I18n.get("File imported successfully"),
                          "success");
            });
        }

        addErrorAlertOption("coral-fileupload:abort");
        addErrorAlertOption("coral-fileupload:error");
        addErrorAlertOption("coral-fileupload:filemimetyperejected");
        addErrorAlertOption("coral-fileupload:filesizeexceeded");
        addErrorAlertOption("coral-fileupload:timeout");
        addSuccessAlertOption("coral-fileupload:load");

        $(document).on("click", i18nDictUploadSelector, function (e) {
            var fileUpload = document.getElementsByTagName("coral-fileupload")[0];
            fileUpload._parameters = [{name: "depth", value: "0"}];
            if (document.getElementsByTagName("coral-checkbox")[0].checked) {
                fileUpload._parameters = fileUpload._parameters.concat({name: "overwrite", value: "on"})
            }
            fileUpload.upload(dictFileName);
            var coralDialog = $(e.target).closest("coral-Dialog");
            var closeButton = $(coralDialog).find("div > button");
            $(closeButton).click();
        });

        $('.importXliffTranslations').click(function () {

            var cancelButton = new Coral.Button().set();
            cancelButton.label = new Coral.Button.Label();
            cancelButton.label.innerText = Granite.I18n.get("Cancel");
            cancelButton.setAttribute('coral-close', '');
            cancelButton.setAttribute('size', 'M');

            var importButton = new Coral.Button().set({
                variant: "primary"
            });
            importButton.label = new Coral.Button.Label();
            importButton.label.innerText = Granite.I18n.get("Import")
            importButton.setAttribute("id", "i18n-dict-import" );
            importButton.setAttribute("disabled", "disabled");
            importButton.setAttribute('size', 'M');

            var footer = cancelButton.outerHTML + importButton.outerHTML;
            var i18nTargetPath = $(document.getElementsByTagName("select")).val();
            if (i18nTargetPath.startsWith('/apps')) {
                i18nTargetPath = i18nTargetPath.replace(/^\/apps/, '/content/cq:i18n');
            } else if (i18nTargetPath.startsWith('/libs')) {
                i18nTargetPath = i18nTargetPath.replace(/^\/libs/, '/content/cq:i18n');
            }

            var content = '<form class="coral-Form coral-Form--aligned" method="post" action="/acccount">'
                + ' <section class="coral-Form-fieldset">' + getInstructionHTML() + getTargetDictHTML(i18nTargetPath)
                + getTargetPathHTML(i18nTargetPath) + getOverwriteCheckbox() + getSlingDictAlertHTML();


            showDialog("importXliffDialog", "default",
                       Granite.I18n.get("Import XLIFF Translations"), content, footer);
        });
    });


    function getTargetPathHTML(i18nTargetPath) {
        return ' <div><label>' + Granite.I18n.get('Target') + '</label> </div> <input disabled="disabled"' +
            ' is="coral-textfield" class="coral-Form-field" type="text" id="filename" style="width: 100%;" value="' +
            Granite.UI.Foundation.Utils.sanitizeHtml(i18nTargetPath) + '"> ';
    }

    function getInstructionHTML() {
        return '<div> <span>' + Granite.I18n.get('Please choose an XLIFF file containing translations.') + '</span> </div>';
    }


    function getSlingDictAlertHTML() {
        var message = Granite.I18n.get("Note: this will create a sling:Message dictionary.");
        return "<coral-alert> " +
            "<coral-alert-header>INFO</coral-alert-header> " +
            "<coral-alert-content>" + message + "</coral-alert-content> " +
            "</coral-alert>"
    }

    function getTargetDictHTML(i18nTargetPath) {
        return ' <br/> <div>' +
            ' <label>' + Granite.I18n.get('XLIFF*') + '</label> </div>' +
            ' <div style="overflow: hidden;"><input' +
            ' is="coral-textfield" class="coral-Form-field" type="text" id="filename" style="width: 85%;" disabled> <coral-fileupload' +
            ' class="coral-Form-field" name="file" action="' + Granite.UI.Foundation.Utils.sanitizeHtml(i18nTargetPath) + '.dict.xliff" async> <button type="button" coral-fileupload-select coral-fileupload-dropzone' +
            ' is="coral-button" variant="secondary" style="margin-left:2px;"> <coral-icon icon="folderSearch"></coral-icon></button>' +
            ' </coral-fileupload> </div>';
    }

    function getOverwriteCheckbox() {
        var message = Granite.I18n.get("Overwrite");
        return '<div class="coral-Form-fieldwrapper coral-Form-fieldwrapper--singleline">'
            + '<coral-checkbox>' + message + '</coral-checkbox>'
            + '</div>';
    }

    function showDialog(id, variant, header, content, footer) {
        var $dialog = $('#' + id);
        var dialog;
        if ($dialog.length === 0) {
            dialog = new Coral.Dialog().set({
                id: id,
                variant: variant,
                closable: "on",
                header: {
                    innerHTML: header
                },
                content: {
                    innerHTML: content
                },
                footer: {
                    innerHTML: footer
                }
            });
            document.body.appendChild(dialog);
        } else {
            dialog = $dialog[0];
            dialog.header.innerHTML = header;
            dialog.content.innerHTML = content;
            dialog.footer.innerHTML = footer;
        }
        dialog.show();
    }
})(document, _g.XSS, Granite.$);