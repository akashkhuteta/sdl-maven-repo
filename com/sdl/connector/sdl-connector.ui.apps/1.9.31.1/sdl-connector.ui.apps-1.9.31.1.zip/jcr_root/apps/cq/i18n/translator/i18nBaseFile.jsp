<%--

  ADOBE CONFIDENTIAL
  __________________

   Copyright 2016 Adobe Systems Incorporated
   All Rights Reserved.

  NOTICE:  All information contained herein is, and remains
  the property of Adobe Systems Incorporated and its suppliers,
  if any.  The intellectual and technical concepts contained
  herein are proprietary to Adobe Systems Incorporated and its
  suppliers and are protected by trade secret or copyright law.
  Dissemination of this information or reproduction of this material
  is strictly forbidden unless prior written permission is obtained
  from Adobe Systems Incorporated.
--%><%@ page import="org.apache.commons.lang3.StringUtils" %>
<%@ include file="/libs/foundation/global.jsp" %><%!
    protected boolean languagesAreEquivalent(String language1, String language2) {

        if (language1 == null || language2 == null) {
            return false;
        }
        language1 = language1.replace("-", "_");
        language2 = language2.replace("-", "_");
        return StringUtils.equalsIgnoreCase(language1, language2);
    }

    protected String getLocaleMapKey(HashMap<String, String> languageMap, String languageKey) {

        if(languageMap == null || languageKey == null) {
            return null;
        }

        String localeMapValue = null;
        String languageWithUnderscores = languageKey.replace("-", "_");
        String languageWithHyphen = languageKey.replace("_", "-");

        if (languageMap.containsKey(languageWithUnderscores)) {
            localeMapValue = languageWithUnderscores;
        } else if (languageMap.containsKey(languageWithHyphen)) {
            localeMapValue = languageWithHyphen;
        }

        return localeMapValue;
    }
%>