/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2015 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */

CQ.Translator.NewTranslationProjectDialog = CQ.Ext.extend(CQ.Translator.Dialog, {
    constructor: function (config) {
        var path = config.path || "/libs/wcm/core/i18n";

        var dlg = this;

        CQ.Ext.applyIf(config, {
            title: "Create Translation Project",
            description: "Please provide project details.",
            closeAction: "close",
            height: 320,
            width: 450,
            formCfg: {
                labelWidth: 150,
                labelPad: 10,
                url: Granite.HTTP.externalize("/etc/workflow/instances")
            },
            items: [
                {
                    xtype: 'textfield',
                    fieldLabel: 'Project Title',
                    width: CQ.Translator.TranslationProject.DefaultInputFieldWidth,
                    name: 'projectTitle',
                    allowBlank: false,
                    listeners: {
                        change: function(field, newValue, oldValue) {
                            field.setValue(Granite.UI.Foundation.Utils.sanitizeHtml(newValue));
                        }
                    }
                },
                {
                    xtype: 'combo',
                    fieldLabel: 'Source Dictionary',
                    hiddenName: 'payload',
                    allowBlank: false,
                    width: CQ.Translator.TranslationProject.DefaultInputFieldWidth,
                    forceSelection:true,
                    itemId: 'srcLangList',
                    typeAhead: true,
                    triggerAction: 'all',
                    lazyRender: true,
                    mode: 'local',
                    store: null,
                    valueField: 'dictPath',
                    displayField: 'displayText',
                    listeners: {
                        afterrender: function (combo) {
                            var recordSelected = combo.getStore().getAt(0);
                            combo.setValue(recordSelected.get('dictPath'));
                        }
                    }
                },

                {
                    xtype: 'combo',
                    fieldLabel: 'Destination Language',
                    hiddenName: 'destinationLanguage',
                    allowBlank: false,
                    width: CQ.Translator.TranslationProject.DefaultInputFieldWidth,
                    forceSelection:true,
                    itemId: 'destLangList',
                    typeAhead: true,
                    triggerAction: 'all',
                    lazyRender: true,
                    mode: 'local',
                    store: null,
                    valueField: 'languageCode',
                    displayField: 'displayText'
                },

                {
                    xtype: 'checkbox',
                    name: 'checkExistingTranslations',
                    fieldLabel: 'Submit only the missing translations',
                    lazyRender: true
                },

                new CQ.Ext.form.TextField({
                    fieldLabel: "Payload Type",
                    name: "payloadType",
                    value: "JCR_PATH",
                    hidden: true
                }),
                new CQ.Ext.form.TextField({
                    fieldLabel: "Workflow Model",
                    name: "model",
                    value: "/etc/workflow/models/wcm-translation/translate-i18n-dictionary/jcr:content/model",
                    hidden: true
                }),
                new CQ.Ext.form.TextField({
                    fieldLabel: "Workflow Title",
                    name: "workflowTitle",
                    value: "Translate I18n Dictionary" ,
                    hidden: true
                }),

                new CQ.Ext.form.TextField({
                    name: '_charset_',
                    value: "utf-8" ,
                    hidden: true
                }),
                CQ.Translator.Dialog.createDescription("<br/><br/>Source Dictionary Path: " + CQ.shared.XSS.getXSSValue(path)),
                CQ.Translator.Dialog.createDescription("Target Dictionary Path: "
                    + CQ.shared.XSS.getXSSValue(CQ.Translator.TranslationProject.getTargetPath(path)))
            ]
        });
        CQ.Translator.NewTranslationProjectDialog.superclass.constructor.call(this, config);


        CQ.Translator.TranslationProject.getI18nDictStore(path,function(store){
            dlg.form.items.get('srcLangList').store = store;
        });

        dlg.form.items.get('destLangList').store = CQ.Translator.TranslationProject.getSupportedLanguageStore();
    },
    handleResult : function(form, action) {
        if(action.response.status == "201"){
            CQ.Ext.MessageBox.wait("Processing dictionaries...", 'Please Wait');
            CQ.Translator.TranslationProject.checkWorkflowStatus(action.response.getResponseHeader('Location'),this);
        }else{
            CQ.Translator.Dialog.DEFAULT_ERROR_HANDLER(form,action);
        }
    },
    ajaxFormSubmit: function () {
        this.form.getForm().submit({
            //url: this.form.url,
            timeout: 60,
            waitMsg: "submitting...",
            success: this.handleResult,
            failure: this.handleResult,
            scope: this
        });
        return true;
    },
    doSubmit: function () {
        return this.ajaxFormSubmit();
    }
});


CQ.Ext.reg("newtranslationprojectdialog", CQ.Translator.NewTranslationProjectDialog);
