<%--
  ADOBE CONFIDENTIAL

  Copyright 2015 Adobe Systems Incorporated
  All Rights Reserved.

  NOTICE:  All information contained herein is, and remains
  the property of Adobe Systems Incorporated and its suppliers,
  if any.  The intellectual and technical concepts contained
  herein are proprietary to Adobe Systems Incorporated and its
  suppliers and may be covered by U.S. and Foreign Patents,
  patents in process, and are protected by trade secret or copyright law.
  Dissemination of this information or reproduction of this material
  is strictly forbidden unless prior written permission is obtained
  from Adobe Systems Incorporated.

--%>
<%@page session="false" import="com.adobe.granite.translation.api.TranslationConfig,
                                com.adobe.granite.ui.components.Config,
                                com.adobe.granite.workflow.WorkflowException,
                                com.adobe.granite.workflow.WorkflowSession,
                                com.adobe.granite.workflow.model.WorkflowModel" %>
<%@ page import="com.day.cq.commons.jcr.JcrConstants" %>
<%@ page import="org.apache.commons.lang3.StringUtils" %>
<%@ page import="org.apache.sling.api.resource.Resource" %>
<%@ page import="javax.jcr.Node" %>
<%@ page import="java.util.HashMap" %>
<%@ page import="org.apache.sling.commons.json.io.JSONWriter" %>
<%@ page import="org.apache.sling.commons.json.JSONException" %>
<%@ page import="javax.jcr.RepositoryException" %>
<%@include file="i18nBaseFile.jsp" %><%
    String i18nPath = request.getParameter("path");
    String targetLanguage = request.getParameter("targetLanguage");
    Resource i18nParentResource = resource.getResourceResolver().getResource(i18nPath);
    if (i18nParentResource != null) {
        Iterable<Resource> childList = i18nParentResource.getChildren();
        TranslationConfig tc = sling.getService(TranslationConfig.class);
        HashMap<String, String> languages = (HashMap<String, String>) tc.getLanguages();
        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");

        JSONWriter w = new JSONWriter(response.getWriter());
        try {
            w.object();
            w.key("dicts");
            w.array();
            for (Resource child : childList) {
                Node node = child.adaptTo(Node.class);
                if (node.isNodeType("mix:language")) {
                    String language = node.getProperty(JcrConstants.JCR_LANGUAGE).getString();
                    if (!StringUtils.isEmpty(language)
                            && (targetLanguage == null || languagesAreEquivalent(targetLanguage,language))) {
                        String localeMapKey = getLocaleMapKey(languages, language);
                        if (localeMapKey != null) {
                            w.object();
                            w.key("lang").value(languages.get(localeMapKey) + " (" + language + ")");
                            w.key("path").value(node.getPath());
                            w.endObject();
                        }
                    }
                }
            }
            w.endArray();
            w.endObject();
        } catch (Exception e) {
        }
    }
%>


