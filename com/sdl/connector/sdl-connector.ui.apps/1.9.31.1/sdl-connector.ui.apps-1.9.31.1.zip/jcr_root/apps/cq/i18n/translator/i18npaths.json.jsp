<%--
  Copyright 1997-2011 Day Management AG
  Barfuesserplatz 6, 4001 Basel, Switzerland
  All Rights Reserved.

  This software is the confidential and proprietary information of
  Day Management AG, ("Confidential Information"). You shall not
  disclose such Confidential Information and shall use it only in
  accordance with the terms of the license agreement you entered into
  with Day.

--%><%@ page session="false" %><%
%><%@ page import="javax.jcr.*,
                   javax.jcr.query.*,
                   java.util.*,
                   org.apache.sling.commons.json.io.JSONWriter" %><%
%><%@ include file="/libs/foundation/global.jsp" %><%

    Set<String> i18nPaths = new HashSet<String>();

    Session session = currentNode.getSession();
    QueryManager qm = session.getWorkspace().getQueryManager();
    QueryResult result = qm.createQuery("//element(*, mix:language)[@jcr:language]", Query.XPATH).execute();
    NodeIterator nodes = result.getNodes();

    while (nodes.hasNext()) {
        Node node = nodes.nextNode();
        if (node.hasNode("..")) {
            i18nPaths.add(node.getParent().getPath());
        }
    }

    response.setContentType("application/json");
    response.setCharacterEncoding("utf-8");
    
    JSONWriter w = new JSONWriter(response.getWriter());
    w.object();
    
    w.key("total").value(i18nPaths.size());
    w.key("paths");
    w.array();
    for (String i18nPath : i18nPaths) {
        w.object();
        w.key("path").value(i18nPath);
        w.endObject();
    }
    w.endArray();
    
    w.endObject();
%>
