<%--
  ADOBE CONFIDENTIAL

  Copyright 2015 Adobe Systems Incorporated
  All Rights Reserved.

  NOTICE:  All information contained herein is, and remains
  the property of Adobe Systems Incorporated and its suppliers,
  if any.  The intellectual and technical concepts contained
  herein are proprietary to Adobe Systems Incorporated and its
  suppliers and may be covered by U.S. and Foreign Patents,
  patents in process, and are protected by trade secret or copyright law.
  Dissemination of this information or reproduction of this material
  is strictly forbidden unless prior written permission is obtained
  from Adobe Systems Incorporated.

--%>
<%@page session="false" import="com.adobe.granite.ui.components.Config,
                                com.adobe.granite.workflow.WorkflowException,
                                com.adobe.granite.workflow.WorkflowSession,
                                com.adobe.granite.workflow.model.WorkflowModel,
                                javax.jcr.Node,
								java.util.ArrayList,
                  java.util.Collections,
                  com.adobe.granite.ui.components.ExpressionHelper,
                  java.util.Comparator,
                  java.util.HashMap,
                  java.util.Iterator,
                  java.util.List,
                  java.text.Collator,
                  org.apache.commons.collections.Transformer,
                  org.apache.commons.collections.iterators.TransformIterator,
                  org.apache.sling.api.resource.Resource,
                  org.apache.sling.api.resource.ResourceMetadata,
                  org.apache.sling.api.resource.ResourceResolver,
                  org.apache.sling.api.resource.ResourceUtil,
                  org.apache.sling.api.resource.ResourceWrapper,
                  org.apache.sling.api.resource.ValueMap,
                  org.apache.sling.api.wrappers.ValueMapDecorator,
                  com.adobe.granite.ui.components.Config,
                  com.adobe.granite.ui.components.ds.DataSource,
                  com.adobe.granite.ui.components.ds.EmptyDataSource,
                  com.adobe.granite.ui.components.ds.SimpleDataSource,
                  com.adobe.granite.ui.components.ds.ValueMapResource" %>
<%@ page import="javax.jcr.NodeIterator" %>
<%@ page import="javax.jcr.Session" %>
<%@ page import="javax.jcr.query.Query" %>
<%@ page import="javax.jcr.query.QueryManager" %>
<%@ page import="javax.jcr.query.QueryResult" %>
<%@ page import="java.util.HashSet" %>
<%@ page import="java.util.Set" %>
<%@ page import="org.apache.commons.lang3.StringUtils" %>
<%
%>
<%@include file="/libs/granite/ui/global.jsp" %>
<%
    final ResourceResolver resolver = resourceResolver;
    Config cfg = new Config(resource.getChild(Config.DATASOURCE));
    ExpressionHelper ex = cmp.getExpressionHelper();
    Session session = resourceResolver.adaptTo(Session.class);
    String targetLanguage = request.getParameter("targetLanguage");
    if (StringUtils.isEmpty(targetLanguage)) {
        targetLanguage = ex.getString(cfg.get("targetLanguage", String.class));
    }
    QueryManager qm = session.getWorkspace().getQueryManager();
    QueryResult queryResult;
    if (StringUtils.isEmpty(targetLanguage)) {
        queryResult = qm.createQuery("//element(*, mix:language)[@jcr:language] order by jcr:path",
                Query.XPATH).execute();
    } else {
          String normalizedLanguage = targetLanguage.replace("_", "-").toLowerCase();
          queryResult = qm.createQuery("//element(*, mix:language)" +
               "[jcr:like(fn:lower-case(@jcr:language), '" + normalizedLanguage + "') or " +
               "jcr:like(fn:lower-case(@jcr:language), '" + targetLanguage.toLowerCase().replace("-", "_") + "')] " +
               " order by jcr:path", Query.XPATH).execute();
    }
    NodeIterator nodes = queryResult.getNodes();

    Set<String> i18nPaths = new HashSet<String>();
	List<KeyValue> dictionaries = new ArrayList<KeyValue>();
    while (nodes.hasNext()) {
        Node node = nodes.nextNode();
        if (node.hasNode("..")) {
            String parentPath = node.getParent().getPath();
            if(i18nPaths.add(parentPath)) {
				dictionaries.add(new KeyValue(parentPath, parentPath)); //XSS

 @SuppressWarnings("unchecked")
        DataSource ds = new SimpleDataSource(new TransformIterator(dictionaries.iterator(), new Transformer() {
            public Object transform(Object input) {
                try {
                    KeyValue lang = (KeyValue) input;

                    ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
                    vm.put("value", lang.key);
                    vm.put("text", lang.value);


                    return new ValueMapResource(resolver, new ResourceMetadata(), "nt:unstructured", vm);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }));

        request.setAttribute(DataSource.class.getName(), ds);
            }
        }
    }
%><%!
    private class KeyValue {
        String key;
        String value;

        public KeyValue(String key, String value) {
            this.key = key;
            this.value = value;
        }
    }
%>

