// Constants
const PASSWORD_PLAIN = '#password-plain';
const PASSWORD = '#password';
const ENCRYPT = '/bin/v2/mantra/encrypt';


window.onload = () => {
    const passwordPlain = document.querySelector(PASSWORD_PLAIN).value;
    if (passwordPlain) {
        document.querySelector(PASSWORD).value = passwordPlain;
    }
};

const encryptPassword = () => {
    $.get(ENCRYPT, {
        toEncrypt: document.querySelector(PASSWORD_PLAIN).value
    }).done((data) => {
        document.querySelector(PASSWORD).value = data;
    });
};