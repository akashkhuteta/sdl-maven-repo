<%--
  Copyright 1997-2011 Day Management AG
  Barfuesserplatz 6, 4001 Basel, Switzerland
  All Rights Reserved.

  This software is the confidential and proprietary information of
  Day Management AG, ("Confidential Information"). You shall not
  disclose such Confidential Information and shall use it only in
  accordance with the terms of the license agreement you entered into
  with Day.

--%><%@ page session="false" %><%
%><%@ page import="java.util.*,
                   org.apache.sling.api.resource.*,
                   org.apache.sling.commons.json.io.JSONWriter,
                   org.slf4j.Logger,
                   javax.jcr.Node,
                   javax.jcr.util.TraversingItemVisitor,
                   org.apache.jackrabbit.util.ISO9075,
                   org.apache.jackrabbit.commons.json.JsonParser,
                   org.apache.jackrabbit.commons.json.JsonHandler,
                   java.io.IOException, java.io.InputStream" %><%
%><%@ include file="/libs/foundation/global.jsp" %><%!

    private Logger log;

    private static class Translation {
        String key;
        String string;
        String comment;
        String[] translations;

        public Translation(String key, int numberOfLanguages) {
            setKey(key);
            initTranslations(numberOfLanguages);
        }

        public void setKey(String key) {
            if (key.endsWith("))")) {
                int commentStart = key.indexOf(" ((");
                if (commentStart == -1) {
                    string = key;
                    comment = "";
                } else {
                    string = key.substring(0, commentStart);
                    comment = key.substring(commentStart + 3, key.length() - 2);
                }
            } else {
                string = key;
                comment = "";
            }
            this.key = key;
        }

        public void initTranslations(int numberOfLanguages) {
            // initialize translations array with empty strings
            translations = new String[numberOfLanguages];
            for (int i = 0; i < translations.length; i++) {
                translations[i] = "";
            }
        }

        public void setTranslation(int languageIndex, String translation) {
            translations[languageIndex] = translation;
        }
    }

    public void addTranslation(Map<String, Translation> translations,
                               String key, String translation, int languageIndex, int numberOfLanguages) {
        Translation t;
        if (translations.containsKey(key)) {
            t = translations.get(key);
        } else {
            t = new Translation(key, numberOfLanguages);
            translations.put(t.key, t);
        }
        t.setTranslation(languageIndex, translation);

    }

%><%

    this.log = log;

    String path = request.getParameter("path");
    if (path == null) path = ""; //"/libs/wcm/core/i18n";

    ResourceResolver resolver = slingRequest.getResourceResolver();
    Resource i18n = resolver.getResource(path);

    final Map<String, Translation> translations = new LinkedHashMap<String, Translation>();

    if (i18n == null) {
        response.sendError(400, "Path '" + path + "' not found.");
        return;
    }

%><%@ include file="languagenodes.jsp" %><%--

    * JSON format:
    
    {
        'results': 2,
        'translations': [
            { 'key': 'source text', 'string': 'source text', 'comment': 'some hint', 'de': 'deutsch', 'fr' : 'francais' },
            { 'key': '2nd text',    'string': '2nd text',    'comment': 'some hint', 'de': 'deutsch', 'fr' : 'francais' }
        ]
    }
--%><%

    for (int i=0; i < languageNodes.size(); i++) {
        Resource dictionaryResource = languageNodes.get(i);

        if (dictionaryResource.getName().endsWith(".json")) {
            // json dictionary
            log.info("loading json dictionary: " + dictionaryResource.getPath());
            final int langIndex = i;
            JsonParser parser = new JsonParser(new JsonHandler() {

                private String key;

                public void key(String key) throws IOException {
                    this.key = key;
                }

                public void value(String value) throws IOException {
                    addTranslation(translations, key, value, langIndex, languageNodes.size());
                }

                public void object() throws IOException {}
                public void endObject() throws IOException {}
                public void array() throws IOException {}
                public void endArray() throws IOException {}
                public void value(boolean value) throws IOException {}
                public void value(long value) throws IOException {}
                public void value(double value) throws IOException {}
            });
            InputStream stream = dictionaryResource.adaptTo(InputStream.class);
            if (stream != null) {
                String encoding = "utf-8";
                ResourceMetadata metadata = dictionaryResource.getResourceMetadata();
                if (metadata != null) { // test does not implement metadata
                    if (metadata.getCharacterEncoding() != null) {
                        encoding = metadata.getCharacterEncoding();
                    }
                }

                try {

                    parser.parse(stream, encoding);

                } catch (IOException e) {
                    log.warn("Could not parse i18n json dictionary {}: {}", dictionaryResource.getPath(), e.getMessage());
                } finally {
                    try {
                        stream.close();
                    } catch (IOException ignore) {
                    }
                }
            } else {
                log.warn("Not a json file: {}", dictionaryResource.getPath());
            }

        } else {
            // classic sling:Message dictionary
            log.info("loading sling:Message dictionary: " + dictionaryResource.getPath());
            final int index = i;
            final int languageNodesSize = languageNodes.size();
            Node dictionaryNode = dictionaryResource.adaptTo(Node.class);
            final TraversingItemVisitor v = new TraversingItemVisitor.Default() {
                @Override
                protected void entering(Node node, int level) throws RepositoryException {
                    if (node.isNodeType("sling:Message") && node.hasProperty("sling:message")) {
                        final String value = node.getProperty("sling:message").getString();
                        final String key = node.hasProperty("sling:key") ? node.getProperty("sling:key").getString() : node.getName();
                        addTranslation(translations, key, value, index, languageNodesSize);
                   }
                }
            };
            v.visit(dictionaryNode);
        }
    }

    response.setContentType("application/json");
    response.setCharacterEncoding("utf-8");

    JSONWriter w = new JSONWriter(response.getWriter());
    w.object();

    w.key("results").value(translations.size());
    w.key("translations");
    w.array();
    for (Translation t: translations.values()) {
        w.object();
        w.key("key").value(t.key);
        w.key("string").value(t.string);
        w.key("comment").value(t.comment);
        for (int i=0; i < t.translations.length; i++) {
            w.key(languages.get(i)).value(t.translations[i]);
        }
        w.endObject();
    }
    w.endArray();

    w.endObject();
%>
