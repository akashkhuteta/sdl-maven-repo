/**
 * Accept language translation (translation job)
 *
 * @param event
 */
const acceptTranslation = (event) => {
    event.stopPropagation();
    showPageLoader(APPROVE_JOB_TEXT);
    const projectPath = getProjectPath(event);
    const jobPath = getJobPath(event);

    $.post(APPROVE_JOB, {
        projectPath,
        jobPath
    }).done(() => {
        forceRefreshStatus(projectPath, () =>
            refreshStatusWithWait(projectPath, jobPath, READY_FOR_REVIEW_CODE, '', () => {
                hidePageLoader();
            })
        );
    }).fail(() => {
        hidePageLoader();
        showErrorDialog(event, FAILED_TO_REJECT_JOB);
    });
};

/**
 * Reject language translation (translation job)
 *
 * @param event
 */
const rejectTranslation = (event) => {
    event.stopPropagation();

    const rejectDialog = document.querySelector(REJECT_DIALOG);
    const commentField = rejectDialog.querySelector(REJECT_COMMENT);
    const commentCharCount = getNextElement(commentField, CHAR_COUNT);

    commentField.off(INPUT).on(INPUT, () => {
        const rejectButton = rejectDialog.querySelector(DIALOG_YES);
        rejectButton.disabled = commentField.value.length > 255;
    });

    commentField.value = '';
    commentField.classList.remove(IS_INVALID);
    commentCharCount.innerText = 255;
    commentCharCount.classList.remove(IS_INVALID);

    showDialog(event, REJECT_DIALOG, () => {
        rejectDialog.hide();

        const projectPath = getProjectPath(event);
        const jobPath = getJobPath(event);
        const comment = commentField.value;

        showPageLoader(REJECT_JOB_TEXT);

        $.post(REJECT_JOB, {
            projectPath,
            jobPath,
            comment
        }).done(() => {
            refreshStatusWithWait(projectPath, jobPath, READY_FOR_REVIEW_CODE, '', () => {
                hidePageLoader();
            });
        }).fail(() => {
            hidePageLoader();
            showErrorDialog(event, FAILED_TO_REJECT_JOB);
        });
    });
};

/**
 * Remove project from jcr
 *
 * @param event
 */
const removeProject = (event) => {
    showDialog(event, DELETE_DIALOG, () => {
        const deleteDialog = document.querySelector(DELETE_DIALOG);
        deleteDialog.hide();

        showPageLoader(DELETE_PROJECT_TEXT);

        const projectPath = getProjectPath(event);

        $.post(DELETE_PROJECT, {
            projectPath
        }).done(() => {
            hidePageLoader();
            if (isOverviewPage()) reloadOverviewTable();
            if (isDetailPage()) window.location.href = '/apps/sdl/connector/overview.html';
        }).fail(() => {
            hidePageLoader();
            showErrorDialog(event, FAILED_TO_DELETE_PROJECT);
        });
    });
};

/**
 * Open wizard to create a new project
 *
 * @param event
 */
const createProject = (event) => {
    isEditMode = false;
    projectPathEditMode = '';
    showDialog(event, WIZARD_DIALOG);
};

/**
 * Open wizard with pre-filled data.
 *
 * @param event
 */
const editProjectSetup = (event) => {
    isEditMode = true;
    projectPathEditMode = getProjectPath(event);
    showDialog(event, WIZARD_DIALOG);
};

/**
 * Show workflow error message for job that has it
 *
 * @param event
 */
const showWorkFlowError = (event) => {
    if (isOverviewPage()) {
        const jobsInError = event.target.closest(ROW).dataset.jobsInError;
        const overviewWorkflowErrorMsg = `${jobsInError} job${jobsInError > 1 ? 's are' : ' is'} ${WORKFLOW_ERROR_OVERVIEW_TEXT}`;
        showErrorDialog(event, overviewWorkflowErrorMsg);
    } else {
        const detailWorkflowErrorMsg = event.target.closest(ROW).dataset.workflowError;
        showErrorDialog(event, detailWorkflowErrorMsg);
    }
};

/**
 * Call the backend to save the project setup from step1 and step2 to jcr
 *
 * @param event
 * @param isStartMode
 */
const saveProject = (event, isStartMode) => {
    showPageLoader(isStartMode ? START_PROJECT_TEXT : SAVE_PROJECT_TEXT);

    //new
    $.ajax({
        type: "POST",
        url: PROJECT_SAVE,
        timeout: 200000,
        data: {
            uuid,
            isStartMode,
            isEditMode,
            projectPathEditMode
        },
        success: function (data) {
            printWizardMsg(step3, data, () => {
                    const projectPath = data.field;

                    if (isDetailPage()) {
                        loadDialogWizardResponseDetail(projectPath, isStartMode)
                    }
                    if (isOverviewPage()) {
                        loadDialogWizardResponseOverview(projectPath, isStartMode);
                    }
                }, () => {
                    hidePageLoader();
                })

        },
        error: function () {
            // Temporary quite dirty fix, for making sure the timeout will not be reached (DTNL-13482)
            window.location.href = '/apps/sdl/connector/overview.html';
            hidePageLoader();
        }
    });

    //old
/*    $.post(PROJECT_SAVE, {
        uuid,
        isStartMode,
        isEditMode,
        projectPathEditMode
    }, {}).done((data) => {
        printWizardMsg(step3, data, () => {
            const projectPath = data.field;

            if (isDetailPage()) {
                loadDialogWizardResponseDetail(projectPath, isStartMode)
            }
            if (isOverviewPage()) {
                loadDialogWizardResponseOverview(projectPath, isStartMode);
            }
        }, () => {
            hidePageLoader();
        });
    }).fail(() => {
        printWizardMsg(step3, {
            type: ERROR,
            message: isStartMode ? UNABLE_TO_START_THE_PROJECT : UNABLE_TO_SAVE_THE_PROJECT
        }, () => {
            hidePageLoader();
        }, () => {
            hidePageLoader();
        });
    });*/
};

/**
 * load the dialog confirmation after a project is created in wizard from the detail page
 *
 * @param projectPath
 */
const loadDialogWizardResponseDetail = (projectPath, isStartMode) => {
    let dialog_action = DIALOG_ACTION_SAVED;
    if (isStartMode) {
        dialog_action = DIALOG_ACTION_STARTED;
        refreshStatusWithWait(projectPath, null, DRAFT_CODE, IS_STARTED_FLAG, () => {
            hidePageLoader();
            wizardDialog.hide();
            reloadDetailTable(projectPath);
            refreshDetail(false);
            setActionToGenericDialog(PROJECT_GENERIC_DIALOG_DETAIL, dialog_action);
            showDialog(event, PROJECT_GENERIC_DIALOG_DETAIL);
        });
    } else {
        hidePageLoader();
        wizardDialog.hide();
        refreshDetail(false);
        setActionToGenericDialog(PROJECT_GENERIC_DIALOG_DETAIL, dialog_action);
        showDialog(event, PROJECT_GENERIC_DIALOG_DETAIL);
    }
};

/**
 * load the dialog confirmation after a project is created in wizard from the overview page
 *
 * @param projectPath
 */
const loadDialogWizardResponseOverview = (projectPath, isStartMode) => {
    let dialog = PROJECT_GENERIC_DIALOG_OVERVIEW;
    let dialog_action = DIALOG_ACTION_CREATED;
    if (isEditMode) {
        dialog_action = DIALOG_ACTION_SAVED;
    }
    if (isStartMode) {
        dialog_action = DIALOG_ACTION_STARTED;
        refreshStatusWithWait(projectPath, null, DRAFT_CODE, IS_STARTED_FLAG, () => {
            hidePageLoader();
            wizardDialog.hide();
            setActionToGenericDialog(dialog, dialog_action);
            showDialog(event, dialog, () => {
                goToDetailPage(projectPath);
            });
            reloadOverviewTable();
        });

          setTimeout(() => {
                    dialog_action = DIALOG_ACTION_STARTED;
                        hidePageLoader();
                        wizardDialog.hide();
                        setActionToGenericDialog(dialog, dialog_action);
                        showDialog(event, dialog, () => {
                            goToDetailPage(projectPath);
                        });
                        reloadOverviewTable();
          }, 60000); // 60 seconds delay

    } else {
        hidePageLoader();
        wizardDialog.hide();
        setActionToGenericDialog(dialog, dialog_action);
        showDialog(event, dialog, () => {
            goToDetailPage(projectPath);
        });
        reloadOverviewTable();
    }
};

/**
 * Set the correct action to the generic project dialog
 *
 * @param dialog
 * @param actionText
 */
const setActionToGenericDialog = (selector, actionText) => {
    const dialog = document.querySelector(selector);
    //Replacing header
    const actionHeader = dialog.querySelector(DIALOG_HEADER).querySelector(DIALOG_PROJECT_ACTION);
    actionHeader.innerText = actionText;

    //Replacing content
    const actionContent = dialog.querySelector(DIALOG_CONTENT).querySelector(DIALOG_PROJECT_ACTION);
    actionContent.innerText = actionText;

    dialog.on(CLOSE, (event) => {
        actionHeader.innerText = '';
        actionContent.innerText = '';
    });
};

/**
 * Call the backend to create a new project and kick-off the project
 *
 * @param event
 */
const startProject = (event) => {
    showPageLoader(START_PROJECT_TEXT);

    const projectPath = getProjectPath(event);

    $.post(PROJECT_START, {
        projectPath
    }).done(() => {
        checkUntilFilesAreCreated(projectPath, () => {
            refreshStatusWithWait(projectPath, null, DRAFT_CODE, IS_STARTED_FLAG, () => {
                hidePageLoader();
                if (isDetailPage()) {
                    reloadDetailTable(projectPath);
                    refreshDetail(false);
                }
            });
        });
    }).fail(() => {
        // Temporary quite dirty fix, for making sure the timeout will not be reached (DTNL-13482)
        window.location.href = '/apps/sdl/connector/overview.html';
        hidePageLoader();
    });
};

/**
 * Go to detail page from the overview page
 *
 * @param projectPath
 */
const goToDetailPage = (projectPath) => {
    window.location.href = convertProjectPathToDetailPagePath(projectPath);
};

/**
 * Approve costs for this project on sdl side
 *
 * @param event
 */
const approveCosts = (event) => {
    showPageLoader(APPROVE_COSTS_TEXT);

    const sdlProjectId = getSdlProjectId(event);
    const projectPath = getProjectPath(event);

    $.post(PROJECT_APPROVE, {
        sdlProjectId,
        projectPath
    }).done((done) => {
        if (done.includes("200")) {
            refreshStatusWithWait(projectPath, null, FOR_APPROVAL_CODE, IS_COSTS_APPROVED_FLAG, () => {
                hidePageLoader();
            });
        } else if (!done.includes("200") && done) {
            forceRefreshStatus(projectPath, () => {
                refreshStatusWithWait(projectPath, null, FOR_APPROVAL_CODE, IS_COSTS_APPROVED_FLAG, () => {
                    hidePageLoader();
                    showErrorDialog(event, done);
                });
            });
        }
    }).fail(() => {
        hidePageLoader();
        showErrorDialog(event, APPROVE_COSTS_FAIL_TEXT);
    });
};

/**
 * Cancel further project translation based on the costs received
 */
const cancelProject = (event) => {
    showDialog(event, CANCEL_DIALOG, () => {
        const cancelDialog = document.querySelector(CANCEL_DIALOG);
        cancelDialog.hide();

        showPageLoader(CANCEL_PROJECT_TEXT);

        const projectPath = getProjectPath(event);

        $.post(PROJECT_CANCEL, {
            projectPath
        }).done(() => {
            refreshStatusUntilInactive(projectPath, () => {
                hidePageLoader();
            });
        }).fail(() => {
            hidePageLoader();
            showErrorDialog(event, CANCEL_PROJECT_FAIL_TEXT);
        });
    });
};

/**
 * Get sdl project id based on the current page
 *
 * @param event
 * @returns {string}
 */
const getSdlProjectId = (event) => {
    if (isOverviewPage()) {
        const row = event.target.closest(ROW);
        return row.dataset.sdlProjectId;
    } else {
        return document.querySelector(SDL_PROJECT_ID).value;
    }
};

/**
 * Get project path based on the current page
 *
 * @param event
 * @returns {string}
 */
const getProjectPath = (event) => {
    if (isOverviewPage()) {
        const row = event.target.closest(ROW);
        return row.dataset.foundationCollectionItemId;
    } else {
        return document.querySelector(PROJECT_PATH).value;
    }
};

/**
 * Get job path based on the current page
 *
 * @param event
 * @returns {string}
 */
const getJobPath = (event) => {
    if (isDetailPage()) {
        const row = event.target.closest(ROW);
        return row.dataset.jobPath;
    }
};

/**
 * Export translation files in XML
 */
const exportXml = (event) => {
    event.stopPropagation();
    const jobPath = getJobPath(event);

    $.get(EXPORT_XML_ZIP, {
        jobPath
    }).done((data) => {
        showPageLoader(PREPARING_XML_ZIP_TEXT);

        setTimeout(function () {
            hidePageLoader();
            window.location.href = data;
        }, 2000);
    }).fail(() => {
        showErrorDialog(event, FAILED_TO_EXPORT_XML_ZIP_TEXT)
    });
};

/**
 * Check until files are created in order to start the project
 *
 * @param projectPath
 * @param done
 */
const checkUntilFilesAreCreated = (projectPath, done) => {
    setTimeout(() => {
        getProject(projectPath, (project) => {
            const pagePaths = project.pagePaths;
            const jobs = project.jobs;

            let filesCreated = false;

            jobs.forEach((job) => {
                const pages = job.files.filter(file => file.fileType === PAGE);
                filesCreated = pages.length >= pagePaths.length;
            });

            if (filesCreated) done();
            else checkUntilFilesAreCreated(projectPath, done);
        });
    }, 3000);
};

/**
 * Force refresh the project (inc. jobs and files status) when doing some action.
 *
 * @param projectPath
 * @param done
 */
const forceRefreshStatus = (projectPath, done) => {
    $.post(FORCE_REFRESH_STATUS, {
        projectPath
    }).done(() => {
        if (done) done();
    });
};

/**
 * Refresh the project and wait until the project becomes inactive. This function should be
 * only used for cancelling or completing the project.
 *
 * @param projectPath
 * @param done
 */
const refreshStatusUntilInactive = (projectPath, done) => {
    getProject(projectPath, () => {
        checkUntilProjectInactive(projectPath, () => {
            if (isOverviewPage()) refreshOverviewItem(projectPath);
            if (isDetailPage()) refreshDetail(false);
            if (done) done();
        });
    });
};

/**
 * Refresh the project (inc. jobs and files status) when doing some action.
 * When done check until next status is reached or check any flag e.g isStarted if it's
 * true or false.
 *
 * @param projectPath
 * @param jobPath
 * @param prevStatusCode
 * @param flag
 * @param done
 */
const refreshStatusWithWait = (projectPath, jobPath, prevStatusCode, flag, done) => {
    getProject(projectPath, () => {
        checkUntilNextStatusIsReachedOrFlagIsTrue(projectPath, jobPath, prevStatusCode, flag, () => {
            if (isOverviewPage()) refreshOverviewItem(projectPath);
            if (isDetailPage()) refreshDetail(false);
            if (done) done();
        });
    });
};

/**
 * Check until the project become inactive. This function should only be used for
 * cancelling or completing the project.
 *
 * @param projectPath
 * @param done
 */
const checkUntilProjectInactive = (projectPath, done) => {
    setTimeout(() => {
        getProject(projectPath, (project) => {
            if (!project.active) {
                if (done) done();
            } else {
                checkUntilProjectInactive(projectPath, done);
            }
        });
    }, 3000);
};

/**
 * Check until next status is reached or check any flag e.g isStarted if it's
 * true or false.
 *
 * @param projectPath
 * @param jobPath
 * @param prevStatusCode
 * @param flag
 * @param done
 */
const checkUntilNextStatusIsReachedOrFlagIsTrue = (projectPath, jobPath, prevStatusCode, flag, done) => {
    setTimeout(() => {
        getProject(projectPath, (project) => {
            const statusCode = determineStatusCode(project, projectPath, jobPath, prevStatusCode);
            if (statusCode !== prevStatusCode || project[flag]) {
                if (done) done();
            } else {
                checkUntilNextStatusIsReachedOrFlagIsTrue(projectPath, jobPath, prevStatusCode, flag, done);
            }
        });
    }, 3000);
};

/**
 * Determine the status code based on the project or job
 *
 * @param project
 * @param projectPath
 * @param jobPath
 * @param prevStatusCode
 * @returns {string|*|number|string}
 */
const determineStatusCode = (project, projectPath, jobPath, prevStatusCode) => {
    if (jobPath == null) {
        return project.calculatedStatus.code;
    }
    const job = project.jobs.find(job => job.jobPath === jobPath);
    return job ? job.calculatedStatus.code : prevStatusCode;
};

/**
 * Check projects status and do something when done
 *
 * @param done
 */
const getProjects = (done) => {
    $.get(PROVIDE_PROJECTS).done((projects) => {
        if (done) done(projects);
    })
};

/**
 * Check single project status and do something when done
 *
 * @param projectPath
 * @param done
 */
const getProject = (projectPath, done) => {
    $.get(PROVIDE_PROJECT, {
        projectPath
    }).done((project) => {
        if (done) done(project);
    }).fail(() => {
          hidePageLoader();
          showErrorDialog(event, "Could not find project in AEM Repository!");
    });
};

/**
 * Retry project
 * @param event
 */
const retryFailedProject = (event) => {
    showDialog(event, RETRY_DIALOG, () => {
        const retryDialog = document.querySelector(RETRY_DIALOG);
        retryDialog.hide();

        showPageLoader(RETRY_PROJECT_TEXT);

        const projectPath = getProjectPath(event);

        $.post(RETRY_FAILED_PROJECT, {
            projectPath
        }).done(() => {
            hidePageLoader();
            if (isOverviewPage()) reloadOverviewTable();
            if (isDetailPage()) window.location.href = '/apps/sdl/connector/overview.html';
        }).fail(() => {
            hidePageLoader();
            showErrorDialog(event, FAILED_TO_RETRY_PROJECT);
        });
    });
};