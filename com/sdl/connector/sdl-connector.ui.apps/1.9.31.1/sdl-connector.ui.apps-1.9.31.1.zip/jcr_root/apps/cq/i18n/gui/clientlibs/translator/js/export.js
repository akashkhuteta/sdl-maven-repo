/*
 ADOBE CONFIDENTIAL

 Copyright 2018 Adobe Systems Incorporated
 All Rights Reserved.

 NOTICE:  All information contained herein is, and remains
 the property of Adobe Systems Incorporated and its suppliers,
 if any.  The intellectual and technical concepts contained
 herein are proprietary to Adobe Systems Incorporated and its
 suppliers and may be covered by U.S. and Foreign Patents,
 patents in process, and are protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material
 is strictly forbidden unless prior written permission is obtained
 from Adobe Systems Incorporated.
 */
(function (document, XSS, $) {
    "use strict";
    $(document).ready(function () {
        var importButton = document.getElementsByClassName("importXliffTranslations");
        var parent = $(importButton).parent()[0];
        var button = new Coral.Button().set({
            label: {
                innerHTML: Granite.I18n.get("Export XLIFF Translations")
            },
            iconSize: "S"
        });
        button.id = "exportButton";
        button.className += " foundation-toggleable-control";
        parent.appendChild(button);

        //add anchorlist for popover
        var anchorlist = new Coral.AnchorList();

        var languageOverlayPath = Granite.HTTP.externalize("/etc/languages/languages");
        var jsonURL = languageOverlayPath + ".1.json";
        var languages = ['de', 'es', 'fr', 'it', 'pt-br', 'zh-cn', 'zh-tw', 'ja', 'ko-kr'];

        //load export languages
        function loadExportLanguages() {
            for (var id in languages) {
                var content = new Coral.List.Item.Content();
                $(content).text("Export full " + languages[id] + " xliff");
                var item = new Coral.AnchorList.Item().set({content: content});
                item.setAttribute("data-language", languages[id].toLowerCase());
                item.setAttribute("icon", "fileXML");
                item.content.style.display = "inline-block";
                anchorlist.append(item);
            }

            //Add export popover
            var popover = new Coral.Popover().set({
                placement: "bottom",
                content: {
                    innerHTML: anchorlist.outerHTML
                },
                target: "#exportButton"
            });
            popover.className += " granite-pulldown-overlay";
            $(popover).attr("alignMy", "left top");
            $(popover).attr("alignAt", "left bottom");
            parent.appendChild(popover);
        }


        $.ajax({
            dataType: 'json',
            url: jsonURL,
            success: function(data) {
                if(data['languages'].length > 0) {
                    languages = data['languages'];
                }
                loadExportLanguages();
            },
            error: function() {
                loadExportLanguages();
            }
        });

        $(document).on('click', '[is="coral-anchorlist-item"]', function(e) {
            var i18nPath = $(document.getElementsByTagName("select")).val();
            var path = Granite.HTTP.externalize(i18nPath + "/" + $(e.target).closest("a").data("language") + ".dict.xliff");
            window.open(path, "_blank");
        });

    })
})(document, _g.XSS, Granite.$);