let loadFromCache = true;

/**
 * Reset sorting before doing another sort
 *
 * @param headerCells
 * @param clickedHeaderCell
 */
const resetSorting = (headerCells, clickedHeaderCell) => {
    headerCells.forEach((headerCell) => {
        const headerText = headerCell.innerText.trim();
        const clickedHeaderText = clickedHeaderCell.innerText.trim();
        if (headerText === clickedHeaderText) {
            return;
        }

        headerCell.setAttribute(SORT_DIR, Coral.Table.Column.sortableDirection.DEFAULT);
        headerCell.setAttribute(ARIA_SORT, NONE);
    });
};

/**
 * PreSort if has sorting in the URL
 *
 * Set timeout because the header columns are not yet populated
 *
 * @param headerCells
 */
const preSorting = (headerCells) => {
    setTimeout(() => {
        headerCells.forEach((headerCell) => {
            const headerSortName = headerCell.innerText.trim().replace(' ', '-').toLowerCase();
            const sortName = getQueryParam(window.location.search, SORT_PARAM);
            const sortDir = getQueryParam(window.location.search, ORDER_PARAM);

            if (headerSortName === sortName) {
                updateSortingHtml(headerCell, sortDir, Coral.Table.Column.sortableDirection);
            }
        });
    }, 1000);
};

/**
 * Sort table
 *
 * @param table
 * @param headerCell
 */
const sorting = (table, headerCell) => {
    const sortDirs = Coral.Table.Column.sortableDirection;
    const currSortDir = headerCell.getAttribute(SORT_DIR);

    const sortName = headerCell.innerText.trim().replace(' ', '-').toLowerCase();
    const sortDir = determineNextSortDir(currSortDir, sortDirs);

    updateQueryStringWithoutReload(SORT_PARAM, sortName);
    updateQueryStringWithoutReload(ORDER_PARAM, sortDir);

    updateSortingHtml(headerCell, sortDir, sortDirs);

    filter();
};

/**
 * Update the sorting to the html
 *
 * @param headerCell
 * @param sortDir
 * @param sortDirs
 */
const updateSortingHtml = (headerCell, sortDir, sortDirs) => {
    headerCell.setAttribute(SORT_DIR, sortDir);
    headerCell.setAttribute(ARIA_SORT, sortDir === sortDirs.DEFAULT ? NONE : sortDir);
};

/**
 * Determine sort direction based on the current sort direction
 *
 * @param currSortDir
 * @param sortDirs
 * @return {*}
 */
const determineNextSortDir = (currSortDir, sortDirs) => {
    switch (currSortDir) {
        case sortDirs.DEFAULT:
            return sortDirs.ASCENDING;
        case sortDirs.ASCENDING:
            return sortDirs.DESCENDING;
        default:
            return sortDirs.DEFAULT;
    }
};

/**
 * Filter by keyword
 *
 * @param searchField
 */
const search = (searchField) => {
    const searchTerm = searchField.value.toLowerCase();
    updateQueryStringWithoutReload(SEARCH_PARAM, searchTerm);
    filter();
};

/**
 * Clear the search term
 */
const clearSearch = () => {
    updateQueryStringWithoutReload(SEARCH_PARAM, '');
    filter();
};

/**
 * Filter by status
 *
 * @param selectBox
 */
const filterByStatus = (selectBox) => {
    updateQueryStringWithoutReload(STATUS_PARAM, selectBox.value);
    filter();
};

/**
 * Switch between active and inactive projects
 *
 * @param projectsToggleEl
 */
const toggleProjects = (projectsToggleEl) => {
    updateQueryStringWithoutReload(ACTIVE_PARAM, projectsToggleEl.checked.toString());
    filter();
};

/**
 * Reload the overview table from the data source
 */
const reloadOverviewTable = () => {
    setFilterFromCache(false);
    filter();
};

/**
 * Clear all filters
 */
const clearFilters = () => {
    const searchField = document.querySelector(SEARCH_FIELD);
    const clearSearchBtn = searchField.querySelector(CORAL_BUTTON);
    const statusSelect = document.querySelector(STATUS_SELECT);
    const activeToggle = document.querySelector(ACTIVE_TOGGLE);

    searchField.value = '';
    clearSearchBtn.style.display = NONE;
    statusSelect.value = '';
    activeToggle.checked = true;

    table.dataset.foundationCollectionSrc = table.dataset.foundationCollectionSrc.split('?')[0];

    resetUrlWithoutReload();
    filter();
};

/**
 * Filter overview items
 */
const filter = () => {
    const requestData = {
        sort: getQueryParam(window.location.search, SORT_PARAM),
        order: getQueryParam(window.location.search, ORDER_PARAM),
        search: getQueryParam(window.location.search, SEARCH_PARAM),
        status: getQueryParam(window.location.search, STATUS_PARAM),
        active: getQueryParam(window.location.search, ACTIVE_PARAM),
        fromCache: loadFromCache
    };

    for (let key in requestData) {
        if (requestData[key] === null || requestData[key] === undefined) {
            delete requestData[key];
        }
    }

    $.get(OVERVIEW_DATA_SOURCE, requestData).done((html) => {
        const parser = $(window).adaptTo(HTML_PARSER);

        parser.parse(html).then((fragment) => {
            const newTable = fragment.firstElementChild;
            const newRows = newTable.querySelectorAll(ROW);

            table.items.clear();

            if (newRows.length === 0) {
                createEmptyRow(table);
            }

            newRows.forEach((newRow) => {
                table.items.add(newRow);
            });

            createFakeRow(table);
        });

        if (requestData.active === TRUE || requestData.active === undefined || requestData.active === null) {
            toggleOverviewRefreshBtn();
        } else {
            disableRefreshBtn(false);
        }

        toggleClearFiltersBtn();
        setFilterFromCache(true);

        // always scroll top while filtering in favour of lazy loading
        const container = table.querySelector(TABLE_CONTAINER);
        container.scrollTo(0, 0);
    });
};

/**
 * Reload the detail table from the data source
 *
 * @param projectPath
 */
const reloadDetailTable = (projectPath) => {
    $.get(DETAIL_DATA_SOURCE, {
        projectPath
    }).done((html) => {
        const parser = $(window).adaptTo(HTML_PARSER);

        parser.parse(html).then((fragment) => {
            const newTable = fragment.firstElementChild;
            const newRows = newTable.querySelectorAll(ROW);

            if (newRows.length === 0) {
                return;
            }

            table.items.clear();
            const expandableRows = table.querySelectorAll(EXPANDABLE_ROW_SELECTOR);
            expandableRows.forEach((expandableRow) => {
                expandableRow.remove();
            });

            newRows.forEach((newRow) => {
                table.items.add(newRow);
            });
        });
    });
};

/**
 * Update the query string without reloading the page
 *
 * @param key
 * @param value
 */
const updateQueryStringWithoutReload = (key, value) => {
    if (history.pushState) {
        const url = `${window.location.protocol}//${window.location.host}${window.location.pathname}`;
        const updatedUrl = `${url}${updateQueryParam(window.location.search, key, value.trim())}`;
        window.history.pushState({path: updatedUrl}, '', updatedUrl);
    }

    // update the foundationCollectionSrc in order lazy loading to cover our filters
    table.dataset.foundationCollectionSrc = updateQueryParam(fixDataSourceUrl(table.dataset.foundationCollectionSrc), key, value.trim());
};

/**
 * Remove query string from the url without reloading the page
 */
const resetUrlWithoutReload = () => {
    if (history.pushState) {
        const url = `${window.location.protocol}//${window.location.host}${window.location.pathname}`;
        window.history.pushState({path: url}, '', url);
    }
};

/**
 * Update the query string with a new parameter
 *
 * @param url
 * @param key
 * @param value
 * @return {string}
 */
const updateQueryParam = (url, key, value) => {
    const pattern = new RegExp('([?&])' + key + '=.*?(&|$)', 'i');
    const match = url.match(pattern);

    if (match) {
        if (value === '') return url.replace(pattern, match[2] !== '' ? match[1] : '');
        return url.replace(pattern, '$1' + key + '=' + encodeURIComponent(value) + '$2');
    }

    if (value !== '' && value !== null && value !== undefined) {
        const separator = url.indexOf('?') !== -1 ? '&' : '?';
        return url + separator + key + '=' + encodeURIComponent(value);
    }

    return url;
};

/**
 * Get query string parameter
 *
 * @param queryString
 * @param key
 * @return {string|null}
 */
const getQueryParam = (queryString, key) => {
    const pattern = new RegExp('[?&]' + key + '(=([^&#]*)|&|#|$)');
    const result = pattern.exec(queryString);
    if (result && result.length === 3) {
        return result[2];
    }

    return null;
};

/**
 * Data source url sometimes contains only ? in the end. Fix it!
 *
 * @param dataSourceUrl
 */
const fixDataSourceUrl = (dataSourceUrl) => {
    const dataSourceUrlLastChar = dataSourceUrl.substr(dataSourceUrl.length - 1);
    return dataSourceUrlLastChar === '?' ? dataSourceUrl.substring(0, dataSourceUrl.length - 1) : dataSourceUrl;
};

/**
 * Filter from cache for better performance
 *
 * @param fromCache
 */
const setFilterFromCache = (fromCache) => {
    loadFromCache = fromCache;
};

/**
 * Toggle icon of the clear filters btn
 */
const toggleClearFiltersBtn = () => {
    const clearFilterBtn = document.querySelector(CLEAR_FILTER_BTN);
    // > 1 in case there is only ? in the url
    if (window.location.search.length > 1) {
        clearFilterBtn.icon = CLOSE_ICON;
        clearFilterBtn.classList.remove(INACTIVE);
        clearFilterBtn.classList.add(ACTIVE);
    } else {
        clearFilterBtn.icon = FILTER_ICON;
        clearFilterBtn.classList.remove(ACTIVE);
        clearFilterBtn.classList.add(INACTIVE);
    }
};