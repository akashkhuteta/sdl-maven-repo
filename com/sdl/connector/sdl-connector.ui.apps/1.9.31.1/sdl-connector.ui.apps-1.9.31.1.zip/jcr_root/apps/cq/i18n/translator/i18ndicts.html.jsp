<%--
  ADOBE CONFIDENTIAL

  Copyright 2015 Adobe Systems Incorporated
  All Rights Reserved.

  NOTICE:  All information contained herein is, and remains
  the property of Adobe Systems Incorporated and its suppliers,
  if any.  The intellectual and technical concepts contained
  herein are proprietary to Adobe Systems Incorporated and its
  suppliers and may be covered by U.S. and Foreign Patents,
  patents in process, and are protected by trade secret or copyright law.
  Dissemination of this information or reproduction of this material
  is strictly forbidden unless prior written permission is obtained
  from Adobe Systems Incorporated.

--%>
<%@page session="false" import="java.util.HashMap,
                                javax.jcr.Node,
                                org.apache.commons.lang3.StringUtils,
                                org.apache.sling.api.resource.Resource,
                                com.adobe.granite.translation.api.TranslationConfig" %>
<%@ page import="com.adobe.granite.ui.components.Config" %>
<%@ page import="com.adobe.granite.workflow.WorkflowException" %>
<%@ page import="com.adobe.granite.workflow.WorkflowSession" %>
<%@ page import="com.adobe.granite.workflow.model.WorkflowModel" %>
<%@ page import="com.day.cq.commons.jcr.JcrConstants" %>
<%@include file="i18nBaseFile.jsp" %>
<%
    String i18nPath = request.getParameter("path");
    String targetLanguage = request.getParameter("targetLanguage");
    Resource i18nParentResource = resource.getResourceResolver().getResource(i18nPath);
    if (i18nParentResource != null) {
        Iterable<Resource> childList = i18nParentResource.getChildren();
        TranslationConfig tc = sling.getService(TranslationConfig.class);
        HashMap<String, String> languages = (HashMap<String, String>) tc.getLanguages();
        for (Resource child : childList) {
            Node node = child.adaptTo(Node.class);
            if ((node != null) && node.isNodeType("mix:language")) {
                String language = node.getProperty(JcrConstants.JCR_LANGUAGE).getString();
                if (!StringUtils.isEmpty(language)
                        && (targetLanguage == null || languagesAreEquivalent(language, targetLanguage))) {
                    String localeMapKey = getLocaleMapKey(languages, language);
                    if (localeMapKey != null) {
%>
<li class="coral-select-item coral-SelectList-item coral-SelectList-item--option"
    data-value="<%= xssAPI.encodeForHTMLAttr(node.getPath()) %>">
    <%= xssAPI.encodeForHTML(languages.get(localeMapKey) + " (" + language + ") - " + node.getName())%>
</li>
<%
                    }
                }
            }
        }
    }
%>


