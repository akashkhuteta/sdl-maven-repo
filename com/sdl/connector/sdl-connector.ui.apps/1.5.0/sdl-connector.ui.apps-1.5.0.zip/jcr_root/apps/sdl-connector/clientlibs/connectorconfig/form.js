// Constants
const PASSWORD_PLAIN = '#password-plain';
const PASSWORD = '#password';
const ENCRYPT = '/bin/v2/mantra/encrypt';

const CONNECTION_INFO = "/bin/v2/mantra/aem/connection/info";

const SERVER = "#server";
const AUTHENTICATION_TYPE = "#authentication-type";
const USERNAME = "#username";
const CLIENT_ID = "#clientId";
const CLIENT_SECRET = "#clientSecret";
const ORG_ID = "#orgId";
const TECH_ACCOUNT = "#techAccount";
const IMS_ENDPOINT = "#imsEndpoint";
const METASCOPE = "#metascope";
const PRIVATE_KEY = "#privateKey";
const PROTOCOL = "#protocol";

const TEST_CONNECTION_SUCCESS = "#test-conn-success-dialog";
const TEST_CONNECTION_FAIL = "#test-conn-fail-dialog";

const testConnection = (testConnBtn) => {

    testConnBtn.disabled = true;

    const server = document.querySelector(SERVER).value;
    const authenticationType = document.querySelector(AUTHENTICATION_TYPE).value;
    const username = document.querySelector(USERNAME)?.value || "";
    const password = document.querySelector(PASSWORD)?.value || "";
    const clientId = document.querySelector(CLIENT_ID)?.value || "";
    const clientSecret = document.querySelector(CLIENT_SECRET)?.value || "";
    const orgId = document.querySelector(ORG_ID)?.value || "";
    const techAccount = document.querySelector(TECH_ACCOUNT)?.value || "";
    const imsEndpoint = document.querySelector(IMS_ENDPOINT)?.value || "";
    const metascope = document.querySelector(METASCOPE)?.value || "";
    const privateKey = document.querySelector(PRIVATE_KEY)?.value || "";
    const protocol = document.querySelector(PROTOCOL).value;


    $.get(CONNECTION_INFO, {
        server,
        authenticationType,
        username,
        password,
        clientId,
        clientSecret,
        orgId,
        techAccount,
        imsEndpoint,
        metascope,
        privateKey,
        protocol
    }).done(() => {
        document.querySelector(TEST_CONNECTION_SUCCESS).show();
    }).fail((xhr) => {
        console.error("Connection test failed", xhr);
        document.querySelector(TEST_CONNECTION_FAIL).show();
    }).always(() => {
        testConnBtn.disabled = false;
    });
};



window.onload = () => {
     const authType = document.querySelector('#authentication-type').value;
       if (authType === 'BASIC') {

           document.querySelectorAll('.tokenAuthConfig').forEach(el => {
                   el.style.display = 'none';
                    el.removeAttribute('required');
               });

               document.querySelectorAll('.basicAuthConfig').forEach(el => {
                   el.style.display = 'block';
                    el.setAttribute('required', 'required');
               });
       } else if (authType === 'TOKEN') {
          document.querySelectorAll('.tokenAuthConfig').forEach(el => {
                  el.style.display = 'block';
                   el.setAttribute('required', 'required');
              });

              document.querySelectorAll('.basicAuthConfig').forEach(el => {
                  el.style.display = 'none';
                   el.removeAttribute('required');
              });
       }
    const passwordPlain = document.querySelector(PASSWORD_PLAIN).value;
    if (passwordPlain) {
        document.querySelector(PASSWORD).value = passwordPlain;
    }
};

const encryptPassword = () => {
    $.get(ENCRYPT, {
        toEncrypt: document.querySelector(PASSWORD_PLAIN).value
    }).done((data) => {
        document.querySelector(PASSWORD).value = data;
    });
};

const onAuthenticationTypeChange = () => {
    const authType = document.querySelector('#authentication-type').value;
    if (authType === 'BASIC') {

        document.querySelectorAll('.tokenAuthConfig').forEach(el => {
                el.style.display = 'none';
                 el.removeAttribute('required');
            });

            document.querySelectorAll('.basicAuthConfig').forEach(el => {
                el.style.display = 'block';
                 el.setAttribute('required', 'required');
            });
    } else if (authType === 'TOKEN') {
       document.querySelectorAll('.tokenAuthConfig').forEach(el => {
               el.style.display = 'block';
                el.setAttribute('required', 'required');
           });

           document.querySelectorAll('.basicAuthConfig').forEach(el => {
               el.style.display = 'none';
                el.removeAttribute('required');
           });
    }
 };

