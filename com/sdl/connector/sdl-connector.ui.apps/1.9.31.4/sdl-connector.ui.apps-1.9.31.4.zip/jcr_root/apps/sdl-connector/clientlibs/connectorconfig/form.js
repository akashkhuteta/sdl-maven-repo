// Constants
const PASSWORD_PLAIN = '#password-plain';
const PASSWORD = '#password';
const ENCRYPT = '/bin/v2/mantra/encrypt';


window.onload = () => {
     const authType = document.querySelector('#authentication-type').value;
       if (authType === 'BASIC') {

           document.querySelectorAll('.tokenAuthConfig').forEach(el => {
                   el.style.display = 'none';
                    el.removeAttribute('required');
               });

               document.querySelectorAll('.basicAuthConfig').forEach(el => {
                   el.style.display = 'block';
                    el.setAttribute('required', 'required');
               });
       } else if (authType === 'TOKEN') {
          document.querySelectorAll('.tokenAuthConfig').forEach(el => {
                  el.style.display = 'block';
                   el.setAttribute('required', 'required');
              });

              document.querySelectorAll('.basicAuthConfig').forEach(el => {
                  el.style.display = 'none';
                   el.removeAttribute('required');
              });
       }
    const passwordPlain = document.querySelector(PASSWORD_PLAIN).value;
    if (passwordPlain) {
        document.querySelector(PASSWORD).value = passwordPlain;
    }
};

const encryptPassword = () => {
    $.get(ENCRYPT, {
        toEncrypt: document.querySelector(PASSWORD_PLAIN).value
    }).done((data) => {
        document.querySelector(PASSWORD).value = data;
    });
};

const onAuthenticationTypeChange = () => {
    const authType = document.querySelector('#authentication-type').value;
    if (authType === 'BASIC') {

        document.querySelectorAll('.tokenAuthConfig').forEach(el => {
                el.style.display = 'none';
                 el.removeAttribute('required');
            });

            document.querySelectorAll('.basicAuthConfig').forEach(el => {
                el.style.display = 'block';
                 el.setAttribute('required', 'required');
            });
    } else if (authType === 'TOKEN') {
       document.querySelectorAll('.tokenAuthConfig').forEach(el => {
               el.style.display = 'block';
                el.setAttribute('required', 'required');
           });

           document.querySelectorAll('.basicAuthConfig').forEach(el => {
               el.style.display = 'none';
                el.removeAttribute('required');
           });
    }
 };